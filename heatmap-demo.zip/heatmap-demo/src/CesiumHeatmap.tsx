import React, { useEffect, useRef, useState } from 'react';
import { Viewer, Entity, Cartesian3, Color, HeightReference } from 'cesium';
import 'cesium/Build/Cesium/Widgets/widgets.css';

const CesiumHeatmap: React.FC = () => {
    const cesiumContainerRef = useRef<HTMLDivElement>(null);
    const viewerRef = useRef<Viewer | null>(null);
    const [csvData, setCsvData] = useState<[number, number, number][]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const loadCSVData = async () => {
            try {
                const response = await fetch('/test-data.csv');
                const csvText = await response.text();
                const lines = csvText.split('\n').filter(line => line.trim());
                const headers = lines[0].split(',');
                const latIndex = headers.findIndex(h => h.trim().toLowerCase() === 'latitude');
                const lonIndex = headers.findIndex(h => h.trim().toLowerCase() === 'longitude');
                const wbgtIndex = headers.findIndex(h => h.trim().toLowerCase() === 'wbgt');
                const data: [number, number, number][] = [];
                
                for (let i = 1; i < lines.length; i++) {
                    const row = lines[i].split(',');
                    if (row.length > Math.max(latIndex, lonIndex, wbgtIndex)) {
                        const lat = parseFloat(row[latIndex]?.trim());
                        const lon = parseFloat(row[lonIndex]?.trim());
                        const wbgt = parseFloat(row[wbgtIndex]?.trim());
                        if (!isNaN(lat) && !isNaN(lon) && !isNaN(wbgt)) {
                            data.push([lon, lat, wbgt]);
                        }
                    }
                }
                
                console.log('Parsed data points:', data.length);
                setCsvData(data);
                setLoading(false);
            } catch (error) {
                console.error('Error loading CSV data:', error);
                setLoading(false);
                setCsvData([]);
            }
        };
        loadCSVData();
    }, []);

    useEffect(() => {
        if (!cesiumContainerRef.current || csvData.length === 0) return;

        const viewer = new Viewer(cesiumContainerRef.current, {
            terrainProvider: undefined,
            homeButton: false,
            sceneModePicker: false,
            baseLayerPicker: false,
            navigationHelpButton: false,
            animation: false,
            timeline: false,
            fullscreenButton: false,
            vrButton: false,
        });

        viewerRef.current = viewer;

        const minTemp = Math.min(...csvData.map(d => d[2]));
        const maxTemp = Math.max(...csvData.map(d => d[2]));

        const getColorFromTemperature = (temp: number) => {
            const normalized = (temp - minTemp) / (maxTemp - minTemp);
            
            if (normalized <= 0.1) return Color.fromCssColorString('rgb(49, 54, 149)');
            if (normalized <= 0.2) return Color.fromCssColorString('rgb(70, 110, 175)');
            if (normalized <= 0.3) return Color.fromCssColorString('rgb(87, 158, 181)');
            if (normalized <= 0.4) return Color.fromCssColorString('rgb(114, 185, 181)');
            if (normalized <= 0.5) return Color.fromCssColorString('rgb(156, 203, 134)');
            if (normalized <= 0.6) return Color.fromCssColorString('rgb(198, 219, 89)');
            if (normalized <= 0.7) return Color.fromCssColorString('rgb(243, 233, 44)');
            if (normalized <= 0.8) return Color.fromCssColorString('rgb(244, 190, 52)');
            if (normalized <= 0.9) return Color.fromCssColorString('rgb(242, 140, 72)');
            return Color.fromCssColorString('rgb(255, 0, 0)');
        };

        csvData.forEach(([lon, lat, temp], index) => {
            if (index % 10 === 0) {
                const entity = new Entity({
                    position: Cartesian3.fromDegrees(lon, lat, 10),
                    point: {
                        pixelSize: 8,
                        color: getColorFromTemperature(temp),
                        outlineColor: Color.WHITE,
                        outlineWidth: 1,
                        heightReference: HeightReference.CLAMP_TO_GROUND,
                        disableDepthTestDistance: Number.POSITIVE_INFINITY,
                    },
                    description: `Tọa độ: ${lon.toFixed(4)}, ${lat.toFixed(4)}<br/>Nhiệt độ: ${temp.toFixed(1)}°C`
                });
                viewer.entities.add(entity);
            }
        });

        if (csvData.length > 0) {
            const centerLon = csvData.reduce((sum, d) => sum + d[0], 0) / csvData.length;
            const centerLat = csvData.reduce((sum, d) => sum + d[1], 0) / csvData.length;
            
            viewer.camera.setView({
                destination: Cartesian3.fromDegrees(centerLon, centerLat, 50000),
            });
        }

        return () => {
            if (viewerRef.current) {
                viewerRef.current.destroy();
                viewerRef.current = null;
            }
        };
    }, [csvData]);

    if (loading) {
        return (
            <div style={{
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                height: '100vh',
                width: '100vw',
                fontSize: '18px'
            }}>
                <div>Đang tải dữ liệu...</div>
            </div>
        );
    }

    if (csvData.length === 0) {
        return (
            <div style={{
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                height: '100vh',
                width: '100vw'
            }}>
                <div>
                    <div style={{ fontSize: '18px' }}>Không có dữ liệu để hiển thị</div>
                    <div style={{ fontSize: '12px', color: '#666', textAlign: 'center', marginTop: '10px' }}>
                        Kiểm tra console để xem thông tin debug
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div>
            <div style={{
                position: 'absolute',
                top: '10px',
                left: '10px',
                zIndex: 1000,
                background: 'rgba(0,0,0,0.8)',
                color: 'white',
                padding: '10px',
                borderRadius: '5px',
                fontSize: '14px'
            }}>
                <div>Tổng số điểm: {csvData.length.toLocaleString()}</div>
                <div>Hiển thị: {Math.ceil(csvData.length / 10).toLocaleString()} điểm</div>
                <div>Nhiệt độ: {Math.min(...csvData.map(d => d[2])).toFixed(1)}°C - {Math.max(...csvData.map(d => d[2])).toFixed(1)}°C</div>
            </div>
            <div 
                ref={cesiumContainerRef}
                style={{
                    width: '100vw',
                    height: '100vh',
                    margin: 0,
                    padding: 0,
                    overflow: 'hidden'
                }}
            />
        </div>
    );
};

export default CesiumHeatmap;
