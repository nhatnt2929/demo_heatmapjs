import React, { useState } from 'react';
import './App.css';
import TemperatureHeatmap from './NoiseHeatmap';
import CesiumHeatmap from './CesiumHeatmap';

function App() {
  const [viewMode, setViewMode] = useState<'2d' | '3d'>('2d');

  return (
    <div className="App">
      <div style={{
        position: 'absolute',
        top: '10px',
        right: '10px',
        zIndex: 1000,
        display: 'flex',
        gap: '10px'
      }}>
        <button
          onClick={() => setViewMode('2d')}
          style={{
            padding: '10px 20px',
            backgroundColor: viewMode === '2d' ? '#007acc' : '#666',
            color: 'white',
            border: 'none',
            borderRadius: '5px',
            cursor: 'pointer',
            fontSize: '14px'
          }}
        >
          2D Heatmap
        </button>
        <button
          onClick={() => setViewMode('3d')}
          style={{
            padding: '10px 20px',
            backgroundColor: viewMode === '3d' ? '#007acc' : '#666',
            color: 'white',
            border: 'none',
            borderRadius: '5px',
            cursor: 'pointer',
            fontSize: '14px'
          }}
        >
          3D Cesium
        </button>
      </div>
      
      {viewMode === '2d' ? <TemperatureHeatmap /> : <CesiumHeatmap />}
    </div>
  );
}

export default App;
