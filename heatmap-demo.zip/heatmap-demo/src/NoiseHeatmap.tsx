import React, { useMemo, useEffect, useState } from 'react';
import ReactECharts from 'echarts-for-react';
import * as echarts from 'echarts';

const TemperatureHeatmap: React.FC = () => {
    const [csvData, setCsvData] = useState<[number, number, number][]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const loadCSVData = async () => {
            try {
                const response = await fetch('/test-data.csv');
                const csvText = await response.text();
                const lines = csvText.split('\n').filter(line => line.trim());
                const headers = lines[0].split(',');
                const latIndex = headers.findIndex(h => h.trim().toLowerCase() === 'latitude');
                const lonIndex = headers.findIndex(h => h.trim().toLowerCase() === 'longitude');
                const wbgtIndex = headers.findIndex(h => h.trim().toLowerCase() === 'wbgt')
                const data: [number, number, number][] = [];
                for (let i = 1; i < lines.length; i++) {
                    const row = lines[i].split(',');
                    if (row.length > Math.max(latIndex, lonIndex, wbgtIndex)) {
                        const lat = parseFloat(row[latIndex]?.trim());
                        const lon = parseFloat(row[lonIndex]?.trim());
                        const wbgt = parseFloat(row[wbgtIndex]?.trim());
                        if (!isNaN(lat) && !isNaN(lon) && !isNaN(wbgt)) {
                            data.push([lon, lat, wbgt]);
                        }
                    }
                }
                console.log('Parsed data points:', data.length);
                setCsvData(data);
                setLoading(false);
            } catch (error) {
                console.error('Error loading CSV data:', error);
                setLoading(false);
                setCsvData([]);
            }
        };
        loadCSVData();
    }, []);

    const { data, uniqueLongitudes, uniqueLatitudes } = useMemo(() => {
        if (csvData.length === 0) {
            return { data: [], uniqueLongitudes: [], uniqueLatitudes: [] };
        }

        const lons = [...new Set(csvData.map(d => d[0]))].sort((a, b) => a - b);
        const lats = [...new Set(csvData.map(d => d[1]))].sort((a, b) => a - b);

        console.log('Unique longitudes:', lons.length);
        console.log('Unique latitudes:', lats.length);

        const heatmapData: [number, number, number][] = [];

        csvData.forEach(([lon, lat, temp]) => {
            const xIndex = lons.indexOf(lon);
            const yIndex = lats.indexOf(lat);
            if (xIndex !== -1 && yIndex !== -1) {
                heatmapData.push([xIndex, yIndex, temp]);
            }
        });

        console.log('Heatmap data points:', heatmapData.length);
        return {
            data: heatmapData,
            uniqueLongitudes: lons,
            uniqueLatitudes: lats
        };
    }, [csvData]);

    const chartOption = useMemo(() => {
        if (data.length === 0) return {};
        const colors = [
            'rgb(49, 54, 149)',
            'rgb(70, 110, 175)',
            'rgb(87, 158, 181)',
            'rgb(114, 185, 181)',
            'rgb(156, 203, 134)',
            'rgb(198, 219, 89)',
            'rgb(243, 233, 44)',
            'rgb(244, 190, 52)',
            'rgb(242, 140, 72)',
            'rgb(255, 0, 0)'
        ];

        echarts.registerMap('heatmap', {
            type: 'FeatureCollection',
            features: []
        });

        return {
            grid: {
                left: '50px',
                right: '50px',
                top: '50px',
                bottom: '50px',
                containLabel: true,
                width: 'auto',
                height: 'auto',
            },
            tooltip: {
                position: 'top',
                formatter: function (params: any) {
                    const lonIndex = params.data[0];
                    const latIndex = params.data[1];
                    const temp = params.data[2];
                    const lon = uniqueLongitudes[lonIndex];
                    const lat = uniqueLatitudes[latIndex];
                    return `Tọa độ: ${lon.toFixed(4)}, ${lat.toFixed(4)}<br/>Nhiệt độ: ${temp.toFixed(1)}°C`;
                }
            },
            xAxis: {
                type: 'category',
                data: uniqueLongitudes.map((_, i) => i % Math.ceil(uniqueLongitudes.length / 10) === 0 ? uniqueLongitudes[i].toFixed(3) : ''),
                splitArea: {
                    show: true
                },
                axisLabel: {
                    fontSize: 10,
                    rotate: 45
                }
            },
            yAxis: {
                type: 'category',
                data: uniqueLatitudes.map((_, i) => i % Math.ceil(uniqueLatitudes.length / 10) === 0 ? uniqueLatitudes[i].toFixed(3) : ''),
                splitArea: {
                    show: true
                },
                axisLabel: {
                    fontSize: 10
                }
            },
            visualMap: {
                min: Math.min(...data.map(d => d[2])),
                max: Math.max(...data.map(d => d[2])),
                calculable: true,
                orient: 'vertical',
                left: 'right',
                top: 'center',
                inRange: {
                    color: colors
                },
                text: ['Cao', 'Thấp'],
                textStyle: {
                    fontSize: 12
                }
            },
            series: [
                {
                    name: 'WBGT',
                    type: 'heatmap',
                    data,
                    label: {
                        show: false
                    },
                    itemStyle: {
                        borderColor: 'rgba(255,255,255,0.1)',
                        borderWidth: 0.5,
                    },
                    emphasis: {
                        itemStyle: {
                            borderColor: '#fff',
                            borderWidth: 2,
                        },
                    },
                    progressive: 1000,
                    animation: false,
                    coordinateSystem: 'cartesian2d',
                },
            ],
        };
    }, [data, uniqueLongitudes, uniqueLatitudes]);

    if (loading) {
        return (
            <div style={{
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                height: '100vh',
                width: '100vw',
                fontSize: '18px'
            }}>
                <div>Đang tải dữ liệu...</div>
            </div>
        );
    }

    if (csvData.length === 0) {
        return (
            <div style={{
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                height: '100vh',
                width: '100vw'
            }}>
                <div>
                    <div style={{ fontSize: '18px' }}>Không có dữ liệu để hiển thị</div>
                    <div style={{ fontSize: '12px', color: '#666', textAlign: 'center', marginTop: '10px' }}>
                        Kiểm tra console để xem thông tin debug
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div style={{
            width: '100vw',
            height: '100vh',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            padding: 0,
            margin: 0
        }}>
            <ReactECharts
                option={chartOption}
                style={{
                    height: '95vh',
                    width: '95vw',
                    aspectRatio: 'auto'
                }}
                opts={{
                    renderer: 'canvas',
                    devicePixelRatio: window.devicePixelRatio || 1
                }}
            />
        </div>
    );
};

export default TemperatureHeatmap;